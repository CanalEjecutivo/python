lista = ["Juana", "Maria", "Pedro", "Pepito"]
lista_num = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]


# ? INDEXACION: EXTRAER UN PEDASO DE UNA LISTA O UNA CADENAS DE TEXTO
print(lista[len(lista) - 2])
print(lista[-1])

# ? SLACING: EXTRAER PARTES O FRAGMENTOS DE UNA LISTA O CADENA DE TEXTO
print(lista[1:3])
print(lista[2:4])
print(lista[-4:-2])
print(lista[-2:])

# ? STRIDE: DAR SALTOS O RECORRIDOS
print(lista_num[0:10:3])
print(lista_num[5:10:2])
print(lista_num[-7::3])
print(lista_num[: len(lista_num) - 5 : 2])

print(lista[::-1])


# ? CON RANGE STRIDE SLACING Y INDEXACION
numeros = list(range(0, 11))
print(numeros[::2])
print(numeros[:6])