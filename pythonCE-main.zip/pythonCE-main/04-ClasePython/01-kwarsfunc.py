# def productos(**datos):
#     print(datos)

# productos(id="45", modelo="TV", nombre="Samsung", desc="Televisor Mi Samsung de 50\"")

# ? IMPRIMIENDO TODOS SUS VALORES O UNO POR UNO
def productos(**datos):
    print(datos["nombre"], datos["id"], datos["desc"])

productos(id="45", modelo="TV", nombre="Samsung", desc="Televisor Mi Samsung de 50\"")