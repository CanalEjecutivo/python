#
# ? METODO AGREGAR AL FINAL DE LA LISTA APPEND()
lista = [1, 2, 3]
lista.append(4)
print(lista)

# ? METODO EXTEND(i)
lista_2 = ["Maria", "Juana"]
lista.extend(lista_2)
print(lista)

# sucesion = list(range(1,51))
# lista.extend(sucesion)
# print(lista)

# ? INSERT (x, y)
lista.insert(2, "Pato")
print(lista)

lista.insert(6, 100)
print(lista)

# ? ELIMINAR LISTA 
lista.remove("Juana") # * DESDE SU VALOR O SU NOMBRE DE ELEMENTO
print(lista)

lista.pop(4) # * DESDE INDEXACION
print(lista)

# ? ELIMINAR TODOS LOS ELEMENTOS DE TU LISTA
lista.clear()
print(lista)

lista.append("Maria")
print(lista)

# ? ELEMENTOS SORT()
lista_numero = [9, 6, 10, 100, 55, 500]
print(lista_numero)
ordenado = sorted(lista_numero)
print(ordenado)
ordenado_m = sorted(lista_numero, reverse=True)
print(ordenado_m)