# def suma(a, b):
#     return a + b
#     # print(a + b)

# print(suma(2, 10))

def suma(a, b):
    resultado = a + b
    return resultado

# ? ALCANSE EN UNA VARIABLE
x = suma(2, 10)
y = suma(x, 20)

print(y)


suma()