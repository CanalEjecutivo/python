serie = ["DBZ", "NARUTO", "POKEMON"]
print(serie[0])

# ? MODIFICAR ELEMENTOS DE MI LISTA
serie[0] = "DBGT"
print(serie)

# ? ELIMINAR ELEMENTOS DE MI LISTA
del serie[2]
print(serie)

# ? MODIFICAR ELEMENTOS DE MI LISTA CON SLACING STRIDE INDEXACION
serie += ["SQUID GAME", "FOUR4", "METEORO"]
print(serie)

serie[:3] = [1, 2, 3]
print(serie)

