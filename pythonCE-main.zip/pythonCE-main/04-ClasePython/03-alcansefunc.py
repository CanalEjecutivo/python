# saludo = "Hola Global"

# def saludar():
#     global saludo
#     saludo = "Hola Mundo"

# def saludarAlumno():
#     global saludo
#     saludo = "Hola estimados alumnos"

# print(saludo)
palabra = input("Ingrese una palabra: ")

def largo(texto):
    resultado = 0
    for letras in texto:
        resultado += 1
    return resultado


funcion_palabra = largo(palabra)
print("La longitud de", palabra, "es de:", funcion_palabra)

