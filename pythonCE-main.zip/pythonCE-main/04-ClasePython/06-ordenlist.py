# lista_grl = [1, 2, "uno", "dos", True, 20.58]
# print(lista_grl)    

# def saludar():
#     print("Hola Mundo")

# lista_nueva = [1, 2, 3, "Hola", saludar()]

# print(len(lista_nueva))
# print(lista_nueva)



