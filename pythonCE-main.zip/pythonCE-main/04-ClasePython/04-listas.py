numero = [1, 2, 3, 4]
print(type(numero))
print(numero)

nombres = ["Juana", "Maria", "Pedro"]
print(type(nombres))
print(nombres)

rango = list(range(1, 11))
print(rango)

saludo = list("Hola Mundo")
print(saludo)