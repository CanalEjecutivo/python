lista_1 = ["t1", "t2", "t3"]
lista_2 = ["t4", "t5", "t6"]
lista_3 = ["t7", "t8", ["t9"], "t10"]

print(lista_2 + lista_1)

print(lista_1 == lista_2)

print("t1" in lista_1)
print(["t1"] in lista_1)
print(lista_1 in lista_2)

print(lista_1 is lista_2)
lista_4 = lista_1
print(lista_4 is lista_1)
