#
# ? Syntax de una Funcion en Python


# def hola():
#     pass


# def holaMundo():
#     print("Hola Mundo")


# var = holaMundo()

# Definicion de funcion
def saludarMaria():
    print("Hola Maria")


# Llamada a la funcion
saludarMaria()
