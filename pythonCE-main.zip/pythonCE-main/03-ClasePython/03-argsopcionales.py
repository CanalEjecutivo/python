# def profesores(nombre, apellido=" "):
#     print("Saludos docente:", nombre, apellido)


# profesores("Juan", "Salas")
# profesores("Maria", "Huaman")
# profesores("Juana")


def profesores(nombre="Sin Nombre", apellido="Sin Apellido"):
    print("Saludos docente:", nombre, apellido)


# nombre = input("Ingrese su nombre: ")
# apellido = input("Ingrese su apellido: ")
profesores("Juan", "Salas")
profesores(apellido="Ramirez", nombre="Lucho")
profesores("Juana")

# profesores(apellido=nombre, nombre=apellido)
