# def saludarEstu(nombre, apellido):
#     print("Bienvenido(a) estudiante:", nombre, apellido)
#     print(nombre, apellido, ",gracias por pertenecer a Canal Ejecutivo")


# nombre = input("Ingrese su nombre: ")
# apellido = input("Ingrese su apellido: ")
# saludarEstu(nombre, apellido)


def saludarProfesor(nombre, correo):
    print("Hola profesor(a): ", nombre)
    print("Su correo es:", correo)


# nombre = input("Ingres su nombre docente: ")
# correo = input("Ingrese su correo docente: ")

# saludarProfesor(nombre, correo)
saludarProfesor("Carlos", "carlos@correo.com")
