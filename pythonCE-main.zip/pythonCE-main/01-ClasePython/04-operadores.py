# 
#? OPERADORES ARITMETICOS
#* + - / *

x = 20
y = 7

print("La suma de X + Y es:", x + y)
print("La resta de X - Y es:", x - y)
print("La multiplicacion de X * Y es:", x * y)

print("La division de X / Y es:", x / y)
print("La division entera de X // Y es:", x // y)
print("La resto de la division es de X % Y es:", x % y)
print("La potenciacion de X y Y es:", x ** y)
