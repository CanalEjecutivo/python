#
#? OPERADOR DE SALIDA
# print("Hola Mundo")

# #? OPERADOR DE ENTRADA  (DATOS)
# input("Digite su nombre: ")

print("bienvenido(a):", input("Ingrese su correo: "))
print()

saludo = "Bienvenido estudiante:"
nombre = input("Digite su nombre: ")
print(saludo, nombre)