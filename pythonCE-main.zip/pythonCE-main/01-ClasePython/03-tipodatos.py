# nombre = "Pepito"
# # print(nombre)
# # nombre = "Maria"
# # print(nombre)
# print(id(nombre))
# edad = 20
# print(id(edad))

# ? TIPOS DE DATOS EN PYTHON
# * TIPO DE DATO STRING
nombre = "Juanita"
print(type(nombre))

# * TIPO DE DATO DE ENTERO
edad = -14
print(type(edad))

# * TIPO DE DATOS FLOTANTES
salario = 200.56
# salario = -23.56 ## POSITIVOS O NEGATIVOS
print(type(salario))

# * TIPO DE DATOS BOOLEANOS
soltero = True
print(type(soltero))


# Nombre2 = "Mariano Melgar"
# print(nombre2)
