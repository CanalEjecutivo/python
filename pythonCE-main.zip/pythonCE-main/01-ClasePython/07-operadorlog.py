nom1 = "Juana"
nom2 = "Juan"
x = 10
y = 5

print(True == False and nom1 == nom2 and x != y and 5 == 5)
# print(10.3 == 10)
# print(nom1 != nom2)

print(not True == True and (x == y or 20 == 20) or "Hola" == "hola")

print(not True)

#!TAREA: Juanita desea calcular la cuenta del restaurante, son 4 personas de las cuales, se debe calcular cuanto le corresponde pagar a cada usuario, a su vez se debe dejar el 5% de comision para el Mozo, y el total a pagar. 