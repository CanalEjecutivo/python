#
#? VARIABLES EN PYTHON
nombre = "Antonio Ramirez"
# print(nombre)
print("Su nombre es:", nombre, "←")
print("Su nombre es: " + nombre + " ←")


edad = 29
print("Su edad es:", edad)
# print("Su edad es:" + edad) # Esto da error

