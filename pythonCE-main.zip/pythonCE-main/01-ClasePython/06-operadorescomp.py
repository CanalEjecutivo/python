#
# ? OPERADORES DE COMPARACION
# * > < == >= <= !=

x = 5
y = 5
# soltero = False #?EXPRESION BOLEANA DE FORMA DIRECTA
# print(soltero)

print(x == y)  # ? IGUAL
print(x != y)  # ? NO IGUAL
print(x > y)  # ? MAYOR A
print(x < y)  # ? MENOR A
print(x >= y)  # ? MAYOR IGUAL  O  MENOR IGUAL
