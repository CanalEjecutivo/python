# Este imprime un Hola Mundo
print("Hola Mundo") # Hola Mundo
# Hola Mundo print("Hola Mundo")

"""
ESTE 
ES  PRINT()
UN 
COMENTARIO
""" 