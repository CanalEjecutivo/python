edad = int(input("Digite su edad: "))

if edad >= 18:
    print("Puede ver la pelicula")
else:
    print("No puede ver la pelicula")
