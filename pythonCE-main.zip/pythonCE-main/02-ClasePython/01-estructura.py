# num1 = 20
# num2 = 20

# if num1 == num2:
#     print("Expresion Verdadera 1")
#     print("Expresion Verdadera 2")

# # ? Usando IF en una lista
# frutas = ["manzana", "platano", "uva"]

# if "uva" in frutas:
#     print("Si existe la fruta")

# CONVERSIONES
# saludo = float(10) + float(8)
# print(saludo)

# edad = str(30)
# nombre = "Jose"
# print(nombre, "tiene", edad)
# print(nombre + " tiene " + edad)

edad = int(input("Digite su edad: "))

if edad > 17:
    print("El usuario puede ver la pelicula")
