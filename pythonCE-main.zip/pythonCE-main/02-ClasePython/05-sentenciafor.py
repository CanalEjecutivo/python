#
# ? FOR CON LISTAS
# frutas = ["Manzana", "Pera", "Platano"]

# for fruta in frutas:
#     print(fruta)

# ? For sobre un rango de numeros (range)

# for i in range(5):
#     print(i)


# for i in range(10, 30, 5):
#     print(i)


# for i in range(10 + 1, 30 + 1, 5):
#     print(i)

# # ? DECREMENTACION
# for i in range(10, 0, -1):
#     print(i)
# print("Empezar!!!!")

# ? SUMAR VALORES DE UN RANGO

contador = 0

for i in range(1, 100):
    contador += i

print("La ssuma es de: ", contador)

# ! TODO: TAREA, CREA UN PROGRAMA CONTADOR DE VOCALES DE UN TEXTO, UTILIZAR VARIABLES, UN FOR, IF, PRINT
