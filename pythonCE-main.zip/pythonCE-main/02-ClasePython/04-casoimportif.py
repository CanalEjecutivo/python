#
# ? SENTENCIA IF EN UNA SOLA LINEA ( NO RECOMENDABLE )

# if 20 != 20: print("Son iguales 1"); print("Son iguales 2"); print("Python es xvr")
# elif 20 == 20: pass
# else: print("No son iguales"); print("Desea intentarlo otra vez?")

# # ? Operador Ternario
# nombre = input("Digite el nombre del lenguaje: ")
# edad = input("Digite su nombre: ")

# # if nombre == "ana":
# #     edad = 20
# # else: 
# #     edad = 10

# edad = 20 if nombre == "ana" else 10

# print(edad)

# mensaje = "hola python" if nombre == "python" else "hola mundo"

# print(mensaje)

# ! TODO: TAREA: CREA UN PROMGRAMA QUE IMPRIMA SI EL USUARIO ES MAYOR DE EDAD O MENOR DE EDAD, CON EL OPERADOR 

# ? ENCADENAR OPERADORES

edad = 30

if edad <= edad <= 60:
    print("Entra a la Piscina")
