#
# ? BREAK
# for numero in range(1, 9):
#     print(numero)
#     break

# numero = 5

# while numero > 0:
#     print(numero)
#     numero -= 1
#     break

# ?  Continue
color = ["azul", "rojo", "verde"]

for colores in color:
    if colores == "azul":
        continue
    print(colores)

# ? PASS
while False:
    pass

if True:
    pass
